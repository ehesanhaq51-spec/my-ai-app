import streamlit as st
from groq import Groq

# পেজ সেটআপ
st.set_page_config(page_title="My AI Assistant", page_icon="🤖")
st.title("🤖 আমার নিজস্ব AI সহকারী")

# আপনার Groq API কীটি নিচের কোটেশনের ভেতর বসান
client = Groq(api_key="আপনার_api_key_এখানে_দিন")

# চ্যাট হিস্টোরি ধরে রাখার জন্য
if "messages" not in st.session_state:
    st.session_state.messages = []

# আগের মেসেজগুলো স্ক্রিনে দেখানো
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# ইউজারের ইনপুট নেওয়া
if prompt := st.chat_input("কী জানতে চান?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # AI এর কাছ থেকে উত্তর নেওয়া
    with st.chat_message("assistant"):
        try:
            chat_completion = client.chat.completions.create(
                messages=[
                    {"role": m["role"], "content": m["content"]}
                    for m in st.session_state.messages
                ],
                model="llama3-8b-8192",
            )
            response = chat_completion.choices[0].message.content
            st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})
        except Exception as e:
            st.error(f"দুঃখিত, একটু সমস্যা হয়েছে: {e}")